# XenonTheInertG dotfiles

1. Clone the repo
 
```bash
git clone https://github.com/XenonTheInertG/Dotfiles.git Dotfiles
```

2. Execute setup

```bash
cd Dotfiles
./setup.sh
```
